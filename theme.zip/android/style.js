export default {
    "app-carousel": {
        "prevBtn": {
            "icon": {
                "color": "#fff"
            }
        },
        "dotsWrapperStyle": {
            "backgroundColor": "transparent"
        },
        "dotStyle": {
            "backgroundColor": "#fff"
        },
        "activeDotStyle": {
            "backgroundColor": "#fff"
        }
    },
    "app-login": {
        "root": {
            "borderRadius": 12,
            "backgroundColor": "#fff"
        }
    },
    "app-login-username": {
        "root": {
            "marginBottom": 25,
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0
        }
    },
    "app-login-password": {
        "root": {
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0,
            "marginBottom": 10
        }
    },
    "usericon": {
        "root": {
            "width": 18,
            "height": 18,
            "position": "absolute",
            "top": -54,
            "right": 12,
            "alignItems": "center",
            "justifyContent": "center",
            "display": "flex"
        },
        "icon": {
            "fontSize": 18
        }
    },
    "pwdicon": {
        "root": {
            "width": 18,
            "height": 18,
            "position": "absolute",
            "top": -40,
            "right": 12,
            "alignItems": "center",
            "justifyContent": "center",
            "display": "flex"
        },
        "icon": {
            "fontSize": 18
        }
    },
    "app-form": {
        "heading": {
            "paddingTop": 0,
            "paddingBottom": 20,
            "display": "flex",
            "alignItems": "center",
            "justifyContent": "center",
            "borderColor": "#ccc"
        },
        "title": {
            "text": {
                "fontSize": 20,
                "color": "#35363b",
                "fontWeight": "400",
                "fontFamily": "Lexend-SemiBold",
                "display": "flex",
                "alignItems": "center",
                "justifyContent": "center"
            }
        },
        "subheading": {
            "text": {
                "color": "#666"
            }
        },
        "root": {
            "backgroundColor": "#fff"
        }
    },
    "app-anchor": {
        "text": {
            "color": "#35363b",
            "paddingLeft": 0,
            "textTransform": "capitalize",
            "fontSize": 14,
            "textDecorationLine": "none",
            "fontFamily": "Lexend-Medium",
            "lineHeight": 18
        },
        "icon": {
            "root": {
                "color": "#35363b"
            }
        },
        "root": {
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0,
            "marginTop": 0,
            "marginRight": 0,
            "marginBottom": 0,
            "marginLeft": 0
        }
    },
    "link-primary": {
        "text": {
            "color": "#656df9"
        },
        "icon": {
            "root": {
                "color": "#656df9"
            }
        },
        "badge": {
            "backgroundColor": "rgba(101,109,249,.2)",
            "color": "#656df9"
        }
    },
    "link-secondary": {
        "text": {
            "color": "#ff6f51"
        },
        "icon": {
            "root": {
                "color": "#ff6f51"
            }
        },
        "badge": {
            "backgroundColor": "rgba(255,111,81,.2)",
            "color": "#ff6f51"
        }
    },
    "link-success": {
        "text": {
            "color": "#08c58a"
        },
        "icon": {
            "root": {
                "color": "#08c58a"
            }
        },
        "badge": {
            "backgroundColor": "rgba(8,197,138,.2)",
            "color": "#08c58a"
        }
    },
    "link-danger": {
        "text": {
            "color": "#ec477c"
        },
        "icon": {
            "root": {
                "color": "#ec477c"
            }
        },
        "badge": {
            "backgroundColor": "rgba(236,71,124,.2)",
            "color": "#ec477c"
        }
    },
    "link-warning": {
        "text": {
            "color": "#ff9642"
        },
        "icon": {
            "root": {
                "color": "#ff9642"
            }
        },
        "badge": {
            "backgroundColor": "rgba(255,150,66,.2)",
            "color": "#ff9642"
        }
    },
    "link-info": {
        "text": {
            "color": "#0295db"
        },
        "icon": {
            "root": {
                "color": "#0295db"
            }
        },
        "badge": {
            "backgroundColor": "rgba(2,149,219,.2)",
            "color": "#0295db"
        }
    },
    "link-light": {
        "text": {
            "color": "#fff"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        },
        "badge": {
            "backgroundColor": "rgba(255,255,255,.2)",
            "color": "#fff"
        }
    },
    "link-dark": {
        "text": {
            "color": "#000"
        },
        "icon": {
            "root": {
                "color": "#000"
            }
        },
        "badge": {
            "backgroundColor": "rgba(0,0,0,.2)",
            "color": "#000"
        }
    },
    "font-base": {
        "text": {
            "fontFamily": "Lexend-Regular"
        }
    },
    "text-underline": {
        "text": {
            "textDecorationLine": "underline",
            "textDecorationColor": "#656df9"
        }
    },
    "app-button": {
        "badge": {
            "backgroundColor": "#6c757d",
            "color": "#fff",
            "borderColor": "#fff"
        },
        "root": {
            "minHeight": 44,
            "paddingTop": 12,
            "paddingRight": 12,
            "paddingBottom": 12,
            "paddingLeft": 12,
            "display": "flex",
            "alignItems": "center",
            "justifyContent": "center",
            "cursor": "pointer",
            "borderColor": "#ccc"
        },
        "text": {
            "textTransform": "uppercase",
            "fontSize": 13,
            "fontFamily": "Lexend-Medium"
        },
        "icon": {
            "root": {
                "width": 16,
                "height": 16,
                "display": "flex",
                "justifyContent": "center",
                "alignItems": "center"
            },
            "text": {
                "fontSize": 13
            }
        }
    },
    "btn-default": {
        "root": {
            "borderColor": "#c5c7ce",
            "backgroundColor": "#fff"
        },
        "text": {
            "color": "#979aa4"
        },
        "badge": {
            "backgroundColor": "#979aa4",
            "color": "#fff",
            "borderColor": "#fff"
        },
        "icon": {
            "root": {
                "color": "#979aa4"
            }
        }
    },
    "btn-info": {
        "root": {
            "borderColor": "#0295db",
            "backgroundColor": "#0295db"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#0295db",
            "borderColor": "#0295db"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-primary": {
        "root": {
            "borderColor": "black",
            "backgroundColor": "#656df9",
            "borderWidth": 0,
            "borderStyle": "solid",
            "backgroundImage": "linear-gradient(257deg,#6a7fff,#9a5aff)"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#656df9",
            "borderColor": "#656df9"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-secondary": {
        "root": {
            "borderColor": "black",
            "backgroundColor": "#ff6f51",
            "borderWidth": 0,
            "borderStyle": "solid",
            "backgroundImage": "linear-gradient(253deg,#ff9642,#ff6f51)"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#ff6f51",
            "borderColor": "#ff6f51"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-danger": {
        "root": {
            "borderColor": "#ec477c",
            "backgroundColor": "#ec477c"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#ec477c",
            "borderColor": "#ec477c"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-success": {
        "root": {
            "borderColor": "#08c58a",
            "backgroundColor": "#08c58a"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#08c58a",
            "borderColor": "#08c58a"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-warning": {
        "root": {
            "borderColor": "#ff9642",
            "backgroundColor": "#ff9642"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#ff9642",
            "borderColor": "#ff9642"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-link": {
        "root": {
            "borderColor": "transparent",
            "backgroundColor": "transparent"
        },
        "text": {
            "color": "#656df9"
        },
        "badge": {
            "backgroundColor": "#656df9",
            "color": "transparent",
            "borderColor": "transparent"
        },
        "icon": {
            "root": {
                "color": "#656df9"
            }
        }
    },
    "btn-dark": {
        "root": {
            "borderColor": "#000",
            "backgroundColor": "#000"
        },
        "text": {
            "color": "#fff"
        },
        "badge": {
            "backgroundColor": "#fff",
            "color": "#000",
            "borderColor": "#000"
        },
        "icon": {
            "root": {
                "color": "#fff"
            }
        }
    },
    "btn-light": {
        "root": {
            "borderColor": "#fff",
            "backgroundColor": "#fff"
        },
        "text": {
            "color": "#000"
        },
        "badge": {
            "backgroundColor": "#000",
            "color": "#fff",
            "borderColor": "#fff"
        },
        "icon": {
            "root": {
                "color": "#000"
            }
        }
    },
    "btn-primary-outline": {
        "root": {
            "borderWidth": 1,
            "borderColor": "#656df9",
            "backgroundColor": "#fff"
        },
        "text": {
            "color": "#656df9"
        },
        "icon": {
            "root": {
                "color": "#656df9"
            }
        }
    },
    "btn-secondary-outline": {
        "root": {
            "borderWidth": 1,
            "borderColor": "#ff6f51",
            "backgroundColor": "#fff"
        },
        "text": {
            "color": "#ff6f51"
        },
        "icon": {
            "root": {
                "color": "#ff6f51"
            }
        }
    },
    "btn-block": {
        "root": {
            "width": "100%"
        }
    },
    "btn-sm": {
        "root": {
            "minHeight": 32,
            "paddingTop": 8,
            "paddingRight": 8,
            "paddingBottom": 8,
            "paddingLeft": 8
        },
        "doneButton": {
            "root": {
                "minWidth": 74
            }
        },
        "nextButton": {
            "root": {
                "minWidth": 74
            }
        },
        "prevButton": {
            "root": {
                "minWidth": 74
            }
        },
        "cancelButton": {
            "root": {
                "minWidth": 88
            }
        }
    },
    "btn-white": {
        "root": {
            "borderWidth": 0
        }
    },
    "btn-md": {
        "root": {
            "minWidth": 158,
            "paddingTop": 16,
            "paddingRight": 12,
            "paddingBottom": 16,
            "paddingLeft": 12
        }
    },
    "btn-filter": {
        "root": {
            "minWidth": 88
        },
        "icon": {
            "root": {
                "color": "#171717"
            }
        },
        "text": {
            "textTransform": "capitalize"
        }
    },
    "app-buttongroup": {
        "root": {
            "borderColor": "#ccc",
            "backgroundColor": "#fff"
        }
    },
    "app-icon": {
        "root": {
            "display": "flex",
            "justifyContent": "center",
            "alignItems": "center"
        },
        "text": {
            "color": "#888c8e",
            "fontSize": 15,
            "alignItems": "center",
            "justifyContent": "center",
            "display": "flex"
        },
        "icon": {
            "display": "flex",
            "justifyContent": "center",
            "alignItems": "center"
        }
    },
    "eyeicon": {
        "root": {
            "position": "absolute",
            "width": 18,
            "height": 18,
            "top": -60,
            "right": 12
        }
    },
    "mailicon": {
        "root": {
            "position": "absolute",
            "width": 18,
            "height": 18,
            "top": -60,
            "right": 12
        }
    },
    "phoneicon": {
        "root": {
            "position": "absolute",
            "width": 18,
            "height": 18,
            "top": -60,
            "right": 12
        }
    },
    "check": {
        "icon": {
            "backgroundColor": "#08c58a",
            "backgroundImage": "linear-gradient(330deg,#84d155,#37bbb2)",
            "color": "#fff",
            "borderRadius": 100
        }
    },
    "whiteicon": {
        "icon": {
            "width": 50,
            "height": 50,
            "color": "#fff",
            "fontSize": 18,
            "borderRadius": 100,
            "backgroundColor": "rgba(51,51,51,.1)"
        }
    },
    "fund-transferaccounticon": {
        "icon": {
            "color": "#a1a5af",
            "fontSize": 30
        }
    },
    "fund-transfer-arrow": {
        "icon": {
            "color": "#fff",
            "fontSize": 12
        }
    },
    "app-label": {
        "root": {
            "color": "#30373b"
        },
        "asterisk": {
            "color": "#ec477c"
        },
        "text": {
            "fontWeight": "400",
            "color": "#30373b",
            "fontSize": 13,
            "fontFamily": "Lexend-Regular"
        }
    },
    "label-danger": {
        "root": {
            "backgroundColor": "#ec477c"
        },
        "text": {
            "color": "#fff"
        }
    },
    "label-primary": {
        "root": {
            "backgroundColor": "#656df9"
        },
        "text": {
            "color": "#fff"
        }
    },
    "label-default": {
        "root": {
            "backgroundColor": "#30373b"
        },
        "text": {
            "color": "#fff"
        }
    },
    "label-success": {
        "root": {
            "backgroundColor": "#08c58a"
        },
        "text": {
            "color": "#fff"
        }
    },
    "label-warning": {
        "root": {
            "backgroundColor": "#ff9642"
        },
        "text": {
            "color": "#fff"
        }
    },
    "label-info": {
        "root": {
            "backgroundColor": "#0295db"
        },
        "text": {
            "color": "#fff"
        }
    },
    "text-danger": {
        "text": {
            "color": "#ec477c"
        }
    },
    "text-primary": {
        "text": {
            "color": "#656df9"
        }
    },
    "text-success": {
        "text": {
            "color": "#08c58a"
        }
    },
    "text-warning": {
        "text": {
            "color": "#ff9642"
        }
    },
    "text-info": {
        "text": {
            "color": "#0295db"
        }
    },
    "h1": {
        "text": {
            "fontSize": 32,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        }
    },
    "h2": {
        "text": {
            "fontSize": 24,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        }
    },
    "h3": {
        "text": {
            "fontSize": 20,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        },
        "root": {
            "marginTop": 12,
            "marginBottom": 18
        }
    },
    "h4": {
        "text": {
            "fontSize": 15,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        }
    },
    "h5": {
        "text": {
            "fontSize": 13,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        }
    },
    "h6": {
        "text": {
            "fontSize": 12,
            "color": "#35363b",
            "fontWeight": "400",
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": 0
        }
    },
    "text-muted": {
        "text": {
            "color": "#73777a"
        }
    },
    "p": {
        "root": {
            "width": "100%"
        }
    },
    "text-color-2": {
        "text": {
            "color": "#36373c"
        }
    },
    "text-white": {
        "text": {
            "color": "#fff"
        }
    },
    "text-mute2": {
        "text": {
            "color": "rgba(48,55,59,.7)"
        }
    },
    "text-gray": {
        "text": {
            "color": "#b5b8ba"
        }
    },
    "text-grid-color": {
        "text": {
            "color": "#35363b"
        }
    },
    "text-mute3-color": {
        "text": {
            "color": "rgba(53,54,59,.9)"
        }
    },
    "text-white-op": {
        "text": {
            "color": "rgba(255,255,255,.7)"
        }
    },
    "font-semibold": {
        "text": {
            "fontFamily": "Lexend-SemiBold"
        }
    },
    "font-medium": {
        "text": {
            "fontFamily": "Lexend-Medium"
        }
    },
    "font-ritalic": {
        "text": {
            "fontFamily": "Roboto-Italic"
        }
    },
    "f-xs": {
        "text": {
            "fontSize": 14
        }
    },
    "f-sm": {
        "text": {
            "fontSize": 16
        }
    },
    "f-m": {
        "text": {
            "fontSize": 18
        }
    },
    "f-h3": {
        "text": {
            "fontSize": 20
        }
    },
    "f-h4": {
        "text": {
            "fontSize": 15
        }
    },
    "f-xxs-3": {
        "text": {
            "fontSize": 11
        }
    },
    "f-xxl": {
        "text": {
            "fontSize": 36
        }
    },
    "f-extralarge": {
        "text": {
            "fontSize": 44
        }
    },
    "text-uppercase": {
        "text": {
            "textTransform": "uppercase"
        }
    },
    "text-capitalize": {
        "text": {
            "textTransform": "capitalize"
        }
    },
    "success-dark-message": {
        "root": {
            "backgroundColor": "#08c58a",
            "borderColor": "transparent"
        },
        "text": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#fff"
                    }
                }
            }
        }
    },
    "error-dark-message": {
        "root": {
            "backgroundColor": "#ec477c",
            "borderColor": "transparent"
        },
        "text": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#fff"
                    }
                }
            }
        }
    },
    "warning-dark-message": {
        "root": {
            "backgroundColor": "#ff9642",
            "borderColor": "transparent"
        },
        "text": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#fff"
                    }
                }
            }
        }
    },
    "info-dark-message": {
        "root": {
            "backgroundColor": "#0295db",
            "borderColor": "transparent"
        },
        "text": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#fff"
                    }
                }
            }
        }
    },
    "loading-dark-message": {
        "root": {
            "backgroundColor": "#0295db",
            "borderColor": "transparent"
        },
        "text": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#fff"
                    }
                }
            }
        }
    },
    "success-light-message": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        },
        "text": {
            "color": "#666"
        },
        "icon": {
            "text": {
                "color": "#08c58a"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#666"
                    }
                }
            }
        }
    },
    "error-light-message": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        },
        "text": {
            "color": "#666"
        },
        "icon": {
            "text": {
                "color": "#ec477c"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#666"
                    }
                }
            }
        }
    },
    "warning-light-message": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        },
        "text": {
            "color": "#666"
        },
        "icon": {
            "text": {
                "color": "#ff9642"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#666"
                    }
                }
            }
        }
    },
    "info-light-message": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        },
        "text": {
            "color": "#666"
        },
        "icon": {
            "text": {
                "color": "#0295db"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#666"
                    }
                }
            }
        }
    },
    "loading-light-message": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        },
        "text": {
            "color": "#666"
        },
        "icon": {
            "text": {
                "color": "#0295db"
            }
        },
        "closeBtn": {
            "root": {
                "icon": {
                    "text": {
                        "color": "#666"
                    }
                }
            }
        }
    },
    "thumbnail-image": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        }
    },
    "app-default-progress-bar": {
        "progressBar": {
            "backgroundColor": "rgba(101,109,249,.15)"
        },
        "progressValue": {
            "color": "#656df9"
        }
    },
    "app-success-progress-bar": {
        "progressBar": {
            "backgroundColor": "rgba(8,197,138,.2)"
        },
        "progressValue": {
            "color": "#08c58a"
        }
    },
    "app-info-progress-bar": {
        "progressBar": {
            "backgroundColor": "rgba(2,149,219,.2)"
        },
        "progressValue": {
            "color": "#0295db"
        }
    },
    "app-danger-progress-bar": {
        "progressBar": {
            "backgroundColor": "rgba(236,71,124,.2)"
        },
        "progressValue": {
            "color": "#ec477c"
        }
    },
    "app-warning-progress-bar": {
        "progressBar": {
            "backgroundColor": "rgba(255,150,66,.2)"
        },
        "progressValue": {
            "color": "#ff9642"
        }
    },
    "app-progress-bar": {
        "root": {
            "height": 10
        },
        "progressBar": {
            "borderRadius": 10
        }
    },
    "app-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(101,109,249,.6)",
            "stroke": "rgba(101,109,249,0.6)"
        },
        "progressValue": {
            "color": "#656df9",
            "stroke": "#656df9"
        },
        "subTitle": {
            "color": "#73777a"
        }
    },
    "app-default-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(101,109,249,.6)",
            "stroke": "rgba(101,109,249,0.6)"
        },
        "progressValue": {
            "color": "#656df9",
            "stroke": "#656df9"
        }
    },
    "app-success-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(8,197,138,.6)",
            "stroke": "rgba(8,197,138,0.6)"
        },
        "progressValue": {
            "color": "#08c58a",
            "stroke": "#08c58a"
        }
    },
    "app-info-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(2,149,219,.6)",
            "stroke": "rgba(2,149,219,0.6)"
        },
        "progressValue": {
            "color": "#0295db",
            "stroke": "#0295db"
        }
    },
    "app-danger-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(236,71,124,.6)",
            "stroke": "rgba(236,71,124,0.6)"
        },
        "progressValue": {
            "color": "#ec477c",
            "stroke": "#ec477c"
        }
    },
    "app-warning-progress-circle": {
        "progressCircle": {
            "backgroundColor": "rgba(255,150,66,.6)",
            "stroke": "rgba(255,150,66,0.6)"
        },
        "progressValue": {
            "color": "#ff9642",
            "stroke": "#ff9642"
        }
    },
    "app-search": {
        "text": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff",
            "minHeight": 44,
            "paddingTop": 12,
            "paddingRight": 12,
            "paddingBottom": 12,
            "paddingLeft": 40,
            "borderTopLeftRadius": 6,
            "borderTopRightRadius": 6,
            "borderBottomRightRadius": 6,
            "borderBottomLeftRadius": 6,
            "borderTopWidth": 1,
            "borderRightWidth": 1,
            "borderBottomWidth": 1,
            "borderLeftWidth": 1
        },
        "invalid": {
            "borderBottomColor": "#ec477c",
            "borderColor": "#ec477c"
        },
        "searchButton": {
            "backgroundColor": "#656df9",
            "icon": {
                "text": {
                    "color": "#888"
                },
                "icon": {
                    "fontSize": 15
                }
            },
            "root": {
                "backgroundColor": "transparent",
                "borderTopLeftRadius": 6,
                "borderTopRightRadius": 6,
                "borderBottomRightRadius": 6,
                "borderBottomLeftRadius": 6,
                "height": 44,
                "paddingTop": 12,
                "paddingRight": 12,
                "paddingBottom": 12,
                "paddingLeft": 12,
                "position": "absolute",
                "left": 4
            }
        },
        "searchItem": {
            "borderBottomColor": "#ddd",
            "color": "#666"
        },
        "placeholderText": {
            "color": "#30373b"
        },
        "modalContent": {
            "display": "none"
        }
    },
    "app-spinner": {
        "icon": {
            "text": {
                "color": "#656df9"
            }
        }
    },
    "app-accordionpane": {
        "root": {
            "borderColor": "#eee",
            "backgroundColor": "#ffffff"
        }
    },
    "app-accordion": {
        "root": {
            "borderColor": "#eee",
            "backgroundColor": "#fff"
        },
        "text": {
            "color": "#333"
        },
        "header": {
            "borderColor": "#eee",
            "backgroundColor": "#fff"
        },
        "activeHeader": {
            "borderColor": "#656df9",
            "backgroundColor": "#656df9"
        },
        "activeHeaderTitle": {
            "color": "#fff"
        },
        "activeIcon": {
            "color": "#fff"
        },
        "badge": {
            "color": "#bbb"
        },
        "activeBadge": {
            "borderColor": "#fff",
            "color": "#fff"
        },
        "default": {
            "backgroundColor": "transparent"
        },
        "danger": {
            "backgroundColor": "#ec477c"
        },
        "success": {
            "backgroundColor": "#08c58a"
        },
        "warning": {
            "backgroundColor": "#ff9642"
        },
        "info": {
            "backgroundColor": "#0295db"
        },
        "primary": {
            "backgroundColor": "#656df9"
        }
    },
    "table-row": {
        "root": {
            "borderColor": "#ccc"
        }
    },
    "table-header-row": {
        "root": {
            "backgroundColor": "#fff"
        }
    },
    "table-striped-row0": {
        "root": {
            "backgroundColor": "rgba(101,109,249,.1)"
        }
    },
    "table-striped-row1": {
        "root": {
            "backgroundColor": "transparent"
        }
    },
    "table": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ccc"
        }
    },
    "text": {
        "color": "#333"
    },
    "border-right": {
        "root": {
            "borderRightWidth": 1,
            "borderColor": "rgba(48,55,59,.2)",
            "borderStyle": "solid"
        }
    },
    "border-line-top": {
        "root": {
            "borderTopWidth": 1,
            "borderStyle": "dashed",
            "borderColor": "rgba(247,247,247,.2)"
        }
    },
    "app-panel-content": {
        "root": {
            "borderColor": "#fff"
        }
    },
    "app-panel-footer": {
        "root": {
            "backgroundColor": "#ddd"
        }
    },
    "app-panel": {
        "root": {
            "backgroundColor": "#fff",
            "paddingTop": 15,
            "paddingRight": 15,
            "paddingBottom": 15,
            "paddingLeft": 15,
            "shadowOffset": {
                "width": 0,
                "height": 30
            },
            "shadowRadius": 120,
            "shadowColor": "rgba(181,190,199,.4)",
            "shadowOpacity": 1
        },
        "text": {
            "color": "#333"
        },
        "header": {
            "backgroundColor": "#fff",
            "borderColor": "#fff"
        },
        "badge": {
            "color": "#fff"
        },
        "default": {
            "backgroundColor": "#30373b",
            "color": "#fff"
        },
        "danger": {
            "backgroundColor": "#ec477c",
            "color": "#fff"
        },
        "success": {
            "backgroundColor": "#08c58a",
            "color": "#fff"
        },
        "warning": {
            "backgroundColor": "#ff9642",
            "color": "#fff"
        },
        "info": {
            "backgroundColor": "#0295db",
            "color": "#fff"
        },
        "primary": {
            "backgroundColor": "#656df9",
            "color": "#fff"
        }
    },
    "panel-default": {
        "header": {
            "backgroundColor": "#000"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "panel-danger": {
        "header": {
            "backgroundColor": "#ec477c"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "panel-success": {
        "header": {
            "backgroundColor": "#08c58a"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "panel-warning": {
        "header": {
            "backgroundColor": "#ff9642"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "panel-info": {
        "header": {
            "backgroundColor": "#0295db"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "panel-primary": {
        "header": {
            "backgroundColor": "#656df9"
        },
        "text": {
            "color": "#fff"
        },
        "subHeading": {
            "color": "#fff"
        },
        "icon": {
            "text": {
                "color": "#fff"
            }
        }
    },
    "app-tabpane": {
        "root": {
            "backgroundColor": "#fff"
        }
    },
    "app-tabs": {
        "root": {
            "borderColor": "#ccc"
        }
    },
    "bg-danger": {
        "root": {
            "backgroundColor": "#ec477c"
        }
    },
    "bg-info": {
        "root": {
            "backgroundColor": "#0295db"
        }
    },
    "bg-primary": {
        "root": {
            "backgroundColor": "#656df9"
        }
    },
    "bg-success": {
        "root": {
            "backgroundColor": "#08c58a"
        }
    },
    "bg-warning": {
        "root": {
            "backgroundColor": "#ff9642"
        }
    },
    "well": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#eee"
        }
    },
    "tile-template-text": {
        "text": {
            "color": "#fff"
        }
    },
    "app-tile": {
        "root": {
            "marginBottom": 18,
            "paddingTop": 25,
            "paddingRight": 25,
            "paddingBottom": 25,
            "paddingLeft": 25,
            "borderRadius": 12
        }
    },
    "active": {
        "root": {
            "shadowOffset": {
                "width": 0,
                "height": 30
            },
            "shadowRadius": 70,
            "shadowColor": "rgba(181,190,199,0)",
            "shadowOpacity": 1,
            "backgroundColor": "rgba(101,109,249,.12)"
        }
    },
    "Ptile-icon": {
        "icon": {
            "fontSize": 11,
            "color": "#fff"
        },
        "text": {
            "fontSize": 11,
            "color": "#fff"
        }
    },
    "app-wizard": {
        "root": {
            "backgroundColor": "#fff"
        },
        "stepTitle": {
            "color": "#35363b",
            "fontFamily": "Lexend-SemiBold",
            "fontSize": 15,
            "lineHeight": 19
        },
        "stepSubTitle": {
            "color": "#35363b"
        },
        "step": {
            "backgroundColor": "#d8d8d8",
            "color": "#999",
            "borderColor": "black",
            "width": "98%",
            "height": 4,
            "borderRadius": 2,
            "borderWidth": 0,
            "borderStyle": "solid",
            "marginRight": 6,
            "position": "absolute",
            "top": 30
        },
        "activeStep": {
            "backgroundColor": "#656df9",
            "borderColor": "#656df9",
            "color": "#fff",
            "marginRight": 6,
            "backgroundImage": "linear-gradient(257deg,#6a7fff,#9a5aff)",
            "position": "absolute",
            "top": 30,
            "fontSize": 0
        },
        "doneStep": {
            "backgroundColor": "linear-gradient(330deg,#84d155,#37bbb2)",
            "borderColor": "#fff",
            "color": "linear-gradient(330deg,#84d155,#37bbb2)",
            "backgroundImage": "linear-gradient(330deg,#84d155,#37bbb2)",
            "borderWidth": 0
        },
        "wizardBody": {
            "borderColor": "transparent",
            "paddingTop": 30,
            "paddingRight": 35,
            "paddingBottom": 20,
            "paddingLeft": 35
        },
        "nextButton": {
            "root": {
                "backgroundColor": "#ff6f51",
                "borderColor": "#ff6f51",
                "backgroundImage": "linear-gradient(253deg,#ff9642,#ff6f51)",
                "borderWidth": 0,
                "marginRight": 0,
                "minWidth": 146
            },
            "icon": {
                "root": {
                    "display": "none"
                }
            },
            "text": {
                "fontSize": 13,
                "lineHeight": 16,
                "textTransform": "uppercase"
            }
        },
        "doneButton": {
            "root": {
                "backgroundColor": "#ff6f51",
                "minWidth": 146,
                "borderColor": "#ff6f51",
                "backgroundImage": "linear-gradient(253deg,#ff9642,#ff6f51)",
                "borderWidth": 0
            },
            "icon": {
                "root": {
                    "display": "none"
                }
            },
            "text": {
                "fontSize": 13,
                "lineHeight": 16,
                "textTransform": "uppercase"
            }
        },
        "stepConnector": {
            "backgroundColor": "#eee",
            "display": "none"
        },
        "stepCounter": {
            "color": "#999",
            "display": "none"
        },
        "numberTextStepConnector": {
            "color": "#999"
        },
        "wizardHeader": {
            "minHeight": 68,
            "backgroundColor": "#f6f6f9",
            "paddingTop": 14,
            "paddingRight": 35,
            "paddingBottom": 14,
            "paddingLeft": 35
        },
        "stepWrapper": {
            "alignItems": "flex-start"
        },
        "stepIcon": {
            "root": {
                "display": "none"
            }
        },
        "wizardFooter": {
            "paddingTop": 20,
            "paddingRight": 35,
            "paddingBottom": 20,
            "paddingLeft": 35,
            "borderTop": "1px solid rgba(151,151,151,.2)",
            "justifyContent": "space-between"
        },
        "prevButton": {
            "root": {
                "borderColor": "#ff6f51",
                "minWidth": 146
            },
            "text": {
                "color": "#ff6f51",
                "backgroundColor": "#fff",
                "fontSize": 13,
                "lineHeight": 16,
                "textTransform": "uppercase"
            },
            "icon": {
                "root": {
                    "display": "none"
                }
            }
        },
        "cancelButton": {
            "root": {
                "marginRight": 30,
                "minWidth": 146
            },
            "text": {
                "fontSize": 13,
                "lineHeight": 16,
                "textTransform": "uppercase"
            }
        }
    },
    "wizard-btn-md": {
        "cancelButton": {
            "root": {
                "minWidth": 96
            }
        },
        "doneButton": {
            "root": {
                "minWidth": 96
            }
        },
        "nextButton": {
            "root": {
                "minWidth": 96
            }
        },
        "prevButton": {
            "root": {
                "minWidth": 96
            }
        }
    },
    "step-none": {
        "wizardHeader": {
            "display": "none"
        }
    },
    "bg-primary-gradient": {
        "root": {
            "borderRadius": 12,
            "backgroundImage": "linear-gradient(130deg,#5176f2,#97afff)"
        }
    },
    "f-row": {
        "content": {
            "flexWrap": "wrap",
            "flexDirection": "row",
            "justifyContent": "center"
        }
    },
    "flex-row": {
        "content": {
            "flexDirection": "row"
        }
    },
    "flex-end": {
        "content": {
            "justifyContent": "flex-end"
        }
    },
    "w-step": {
        "root": {
            "position": "absolute",
            "top": 13,
            "right": 0,
            "paddingTop": 0,
            "paddingRight": 35,
            "paddingBottom": 0,
            "paddingLeft": 35
        }
    },
    "border-dashed": {
        "root": {
            "borderWidth": 1,
            "borderRadius": 100,
            "borderStyle": "solid",
            "borderColor": "#fff",
            "paddingTop": 10,
            "paddingRight": 20,
            "paddingBottom": 10,
            "paddingLeft": 20,
            "shadowOffset": {
                "width": 0,
                "height": 6
            },
            "shadowRadius": 4,
            "shadowColor": "rgba(90,124,239,.05)",
            "shadowOpacity": 1
        }
    },
    "gradient-btn": {
        "root": {
            "backgroundImage": "linear-gradient(257deg,#6a7fff,#9a5aff)",
            "borderRadius": 12
        }
    },
    "border-container-solid": {
        "root": {
            "borderWidth": 1,
            "borderRadius": 6,
            "borderColor": "#e0e1e4"
        }
    },
    "fund-transfer-container": {
        "root": {
            "borderRadius": 100,
            "width": 30,
            "height": 30,
            "backgroundColor": "#656df9",
            "backgroundImage": "linear-gradient(257deg,#6a7fff,#9a5aff)",
            "right": -15,
            "top": 40,
            "position": "absolute"
        },
        "content": {
            "display": "flex",
            "alignItems": "center",
            "justifyContent": "center"
        }
    },
    "app-card-content": {
        "root": {
            "backgroundColor": "#fff",
            "borderRadius": 12,
            "shadowOffset": {
                "width": 0,
                "height": 0
            },
            "shadowRadius": 0,
            "shadowColor": "black",
            "shadowOpacity": 1,
            "paddingTop": 16,
            "paddingRight": 16,
            "paddingBottom": 16,
            "paddingLeft": 16
        }
    },
    "app-card-footer": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#ddd"
        }
    },
    "app-card": {
        "root": {
            "borderColor": "#ddd",
            "shadowColor": "#000000",
            "backgroundColor": "#fff",
            "borderRadius": 12,
            "marginTop": 0
        },
        "heading": {
            "backgroundColor": "#ddd"
        },
        "title": {
            "root": {
                "color": "#333"
            }
        },
        "subheading": {
            "root": {
                "color": "#666"
            }
        }
    },
    "form-label": {
        "text": {
            "fontSize": 14,
            "color": "#73777a",
            "fontFamily": "Lexend-Regular"
        },
        "root": {
            "paddingBottom": 0,
            "marginBottom": 6
        }
    },
    "app-form-field": {
        "root": {
            "marginBottom": 30
        }
    },
    "app-form-footer": {
        "root": {
            "borderColor": "#ccc",
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0,
            "borderTopWidth": 0,
            "borderBottomWidth": 0,
            "borderLeftWidth": 0,
            "borderRightWidth": 0
        }
    },
    "formaction": {
        "root": {
            "marginTop": 0,
            "marginRight": 0,
            "marginBottom": 0,
            "marginLeft": 0
        }
    },
    "f-large": {
        "root": {
            "paddingTop": 35,
            "paddingRight": 35,
            "paddingBottom": 35,
            "paddingLeft": 35,
            "borderRadius": 12
        }
    },
    "app-list-template": {
        "root": {
            "borderBottomColor": "#cccccc",
            "backgroundColor": "#ffffff",
            "borderRadius": 12
        }
    },
    "app-list": {
        "loadingIcon": {
            "text": {
                "color": "#666"
            }
        },
        "heading": {
            "backgroundColor": "#fff"
        },
        "groupHeading": {
            "backgroundColor": "transparent"
        },
        "title": {
            "text": {
                "color": "#333"
            }
        },
        "subheading": {
            "text": {
                "color": "#666"
            }
        },
        "emptyMessage": {
            "text": {
                "color": "#666"
            }
        },
        "item": {
            "shadowOffset": {
                "width": 0,
                "height": 30
            },
            "shadowRadius": 70,
            "shadowColor": "rgba(181,190,199,.15)",
            "shadowOpacity": 1,
            "paddingTop": 16,
            "paddingRight": 10,
            "paddingBottom": 16,
            "paddingLeft": 10,
            "marginTop": 0,
            "borderRadius": 12
        },
        "selectedItem": {
            "shadowOffset": {
                "width": 0,
                "height": 30
            },
            "shadowRadius": 200,
            "shadowColor": "rgba(181,190,199,.15)",
            "shadowOpacity": 1
        },
        "selectedIcon": {
            "root": {
                "display": "none"
            }
        }
    },
    "app-barcodescanner": {
        "button": {
            "root": {
                "backgroundColor": "#fff",
                "borderColor": "#ccc"
            },
            "text": {
                "color": "#30373b"
            },
            "icon": {
                "icon": {
                    "color": "#30373b"
                }
            }
        }
    },
    "app-camera": {
        "button": {
            "root": {
                "backgroundColor": "#fff",
                "borderColor": "#ccc"
            },
            "text": {
                "color": "#30373b"
            },
            "icon": {
                "icon": {
                    "color": "#30373b"
                }
            }
        }
    },
    "app-alertdialog": {
        "message": {
            "text": {
                "color": "#888"
            }
        }
    },
    "app-confirmdialog": {
        "message": {
            "text": {
                "color": "#888"
            }
        }
    },
    "app-dialog": {
        "root": {
            "backgroundColor": "#fff",
            "maxHeight": "100vh",
            "width": "100%",
            "borderRadius": 0
        },
        "header": {
            "borderColor": "#ccc",
            "paddingTop": 20,
            "paddingRight": 20,
            "paddingBottom": 20,
            "paddingLeft": 20
        },
        "content": {
            "maxWidth": "100%"
        },
        "icon": {
            "text": {
                "paddingLeft": 0,
                "fontSize": 20,
                "color": "#35363b",
                "fontFamily": "Lexend-SemiBold"
            }
        },
        "closeBtn": {
            "root": {
                "justifyContent": "flex-start"
            },
            "icon": {
                "root": {
                    "width": 16,
                    "height": 16
                },
                "text": {
                    "color": "#73777a",
                    "fontSize": 15
                }
            }
        }
    },
    "modal-lg": {
        "root": {
            "height": "100%",
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0
        }
    },
    "modal-sm": {
        "root": {
            "borderRadius": 16
        }
    },
    "app-dialogactions": {
        "root": {
            "borderColor": "#ccc"
        }
    },
    "app-dialogcontent": {
        "root": {
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0,
            "maxHeight": "100vh"
        }
    },
    "app-calendar": {
        "text": {
            "color": "calendarDateColor"
        },
        "calendar": {
            "backgroundColor": "#fff",
            "borderColor": "#fff"
        },
        "calendarHeader": {
            "backgroundColor": "#fff",
            "borderColor": "#fff"
        },
        "weekDay": {
            "backgroundColor": "#fff",
            "borderColor": "#fff"
        },
        "weekDayText": {
            "color": "#aaa"
        },
        "day": {
            "backgroundColor": "#fff",
            "color": "#666"
        },
        "monthText": {
            "color": "#30373b"
        },
        "yearText": {
            "color": "#30373b"
        },
        "today": {
            "backgroundColor": "rgba(101,109,249,.3)"
        },
        "todayText": {
            "backgroundColor": "transparent"
        },
        "eventDay1": {
            "color": "rgba(101,109,249,.8)"
        },
        "eventDay2": {
            "color": "rgba(101,109,249,.6)"
        },
        "eventDay3": {
            "color": "rgba(101,109,249,.3)"
        },
        "selectedDay": {
            "backgroundColor": "#656df9"
        },
        "selectedDayText": {
            "color": "#fff"
        },
        "prevMonthBtn": {
            "text": {
                "color": "#aaa"
            }
        },
        "nextMonthBtn": {
            "text": {
                "color": "#aaa"
            }
        },
        "nextYearBtn": {
            "text": {
                "color": "#aaa"
            }
        }
    },
    "app-checkbox": {
        "text": {
            "color": "#656df9"
        }
    },
    "app-checkboxset": {
        "text": {
            "color": "#656df9"
        },
        "groupHeaderTitle": {
            "backgroundColor": "transparent"
        }
    },
    "app-chips": {
        "activeChip": {
            "backgroundColor": "#656df9",
            "borderColor": "#656df9"
        },
        "activeChipLabel": {
            "color": "#fff"
        },
        "clearIcon": {
            "color": "#fff"
        }
    },
    "app-currency": {
        "root": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff"
        },
        "label": {
            "backgroundColor": "#656df9",
            "color": "#fff"
        },
        "invalid": {
            "borderBottomColor": "#ec477c"
        },
        "placeholderText": {
            "color": "rgba(48,55,59,.3)"
        }
    },
    "app-date": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#979aa4",
            "height": 44,
            "paddingTop": 12,
            "paddingRight": 16,
            "paddingBottom": 12,
            "paddingLeft": 16
        },
        "text": {
            "color": "#30373b",
            "fontSize": 15
        },
        "invalid": {
            "borderBottomColor": "#ec477c",
            "borderColor": "#ec477c"
        },
        "clearIcon": {
            "root": {
                "display": "none"
            }
        },
        "calendarIcon": {
            "icon": {
                "fontSize": 15
            }
        }
    },
    "app-datetime": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#979aa4"
        },
        "text": {
            "color": "#30373b"
        },
        "invalid": {
            "borderBottomColor": "#ec477c"
        }
    },
    "app-time": {
        "root": {
            "backgroundColor": "#fff",
            "borderColor": "#979aa4"
        },
        "text": {
            "color": "#30373b"
        },
        "invalid": {
            "borderBottomColor": "#ec477c"
        }
    },
    "app-number": {
        "root": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff",
            "paddingTop": 8,
            "paddingRight": 8,
            "paddingBottom": 8,
            "paddingLeft": 8,
            "fontSize": 22,
            "height": 44,
            "color": "#30373b"
        },
        "invalid": {
            "borderBottomColor": "#ec477c",
            "borderColor": "#ec477c"
        },
        "placeholderText": {
            "color": "rgba(48,55,59,.3)"
        }
    },
    "app-radioset": {
        "text": {
            "color": "#656df9"
        },
        "groupHeaderTitle": {
            "backgroundColor": "transparent"
        }
    },
    "app-rating": {
        "text": {
            "color": "#eb8600"
        },
        "icon": {
            "text": {
                "color": "#aaa"
            }
        },
        "selectedIcon": {
            "text": {
                "color": "#eb8600"
            }
        }
    },
    "app-select": {
        "root": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff",
            "minWidth": 70,
            "height": 44,
            "paddingTop": 10,
            "paddingRight": 12,
            "paddingBottom": 10,
            "paddingLeft": 12,
            "textAlign": "left"
        },
        "invalid": {
            "borderBottomColor": "#ec477c"
        }
    },
    "app-slider": {
        "minimumTrack": {
            "backgroundColor": "#656df9"
        },
        "maximumTrack": {
            "backgroundColor": "#fff"
        },
        "thumb": {
            "backgroundColor": "#656df9",
            "color": "#656df9"
        }
    },
    "app-switch": {
        "button": {
            "backgroundColor": "#fff",
            "borderColor": "#979aa4",
            "flexGrow": 1,
            "flexShrink": 1,
            "flexBasis": 0,
            "minWidth": "auto",
            "width": "auto",
            "paddingTop": 5,
            "paddingRight": 5,
            "paddingBottom": 5,
            "paddingLeft": 5,
            "height": 44
        },
        "selectedButton": {
            "color": "#fff",
            "backgroundColor": "#656df9",
            "flexGrow": 1,
            "flexShrink": 1,
            "flexBasis": 0,
            "minWidth": "auto",
            "width": "auto",
            "borderWidth": 0,
            "borderRightWidth": 0,
            "backgroundImage": "linear-gradient(257deg,#6a7fff,#9a5aff)"
        },
        "root": {
            "width": "100%",
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0
        }
    },
    "app-text": {
        "root": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff",
            "height": 44,
            "paddingTop": 12,
            "paddingRight": 16,
            "paddingBottom": 12,
            "paddingLeft": 16,
            "color": "#30373b",
            "fontSize": 15
        },
        "invalid": {
            "borderBottomColor": "#ec477c",
            "borderColor": "#ec477c"
        }
    },
    "app-textarea": {
        "root": {
            "borderColor": "#979aa4",
            "backgroundColor": "#fff",
            "minHeight": 130,
            "paddingTop": 12,
            "paddingRight": 16,
            "paddingBottom": 12,
            "paddingLeft": 16
        },
        "invalid": {
            "borderBottomColor": "#ec477c"
        },
        "placeholderText": {
            "color": "rgba(48,55,59,.3)"
        }
    },
    "app-toggle": {
        "text": {
            "color": "#656df9"
        },
        "handle": {
            "color": "#656df9"
        }
    },
    "app-appnavbar": {
        "root": {
            "backgroundColor": "#fff",
            "paddingTop": 20,
            "paddingRight": 20,
            "paddingBottom": 20,
            "paddingLeft": 20
        },
        "leftnavIcon": {
            "root": {
                "fontSize": 32,
                "color": "rgba(41,45,50,.4)"
            }
        },
        "backIcon": {
            "root": {
                "fontSize": 32,
                "color": "rgba(41,45,50,.4)"
            }
        },
        "image": {
            "width": 32,
            "height": 32,
            "root": {
                "width": "auto"
            }
        },
        "content": {
            "color": "#151420",
            "fontSize": 24
        },
        "leftSection": {
            "flexGrow": 0,
            "flexShrink": 1,
            "flexBasis": 0
        }
    },
    "navbarAnchorItem": {
        "text": {
            "color": "#151420"
        },
        "icon": {
            "text": {
                "color": "rgba(41,45,50,.4)"
            },
            "icon": {
                "fontSize": 18,
                "color": "rgba(41,45,50,.4)"
            }
        },
        "root": {
            "paddingRight": 0
        }
    },
    "navbarButton": {
        "icon": {
            "text": {
                "color": "#151420"
            }
        },
        "text": {
            "color": "#151420"
        }
    },
    "navbarMenu": {
        "link": {
            "backgroundColor": "transparent",
            "icon": {
                "root": {
                    "fontSize": 32,
                    "color": "#151420"
                }
            },
            "text": {
                "fontSize": 32,
                "color": "#151420"
            }
        }
    },
    "navbarPopover": {
        "link": {
            "icon": {
                "root": {
                    "fontSize": 32,
                    "color": "#151420"
                }
            },
            "text": {
                "fontSize": 32,
                "color": "#151420"
            }
        }
    },
    "flex-left": {
        "leftSection": {
            "flexGrow": 1,
            "flexShrink": 1,
            "flexBasis": 0
        }
    },
    "app-popover": {
        "popover": {
            "backgroundColor": "#fff"
        },
        "title": {
            "backgroundColor": "#ddd",
            "color": "#111"
        }
    },
    "app-menu": {
        "link": {
            "icon": {
                "root": {
                    "color": "#666"
                }
            },
            "text": {
                "color": "#666"
            }
        },
        "menu": {
            "backgroundColor": "#fff"
        },
        "menuItem": {
            "root": {
                "borderBottomColor": "#ccc"
            },
            "icon": {
                "icon": {
                    "color": "#666"
                }
            },
            "text": {
                "color": "#666"
            }
        }
    },
    "app-navitem": {
        "root": {
            "borderColor": "#ccc"
        },
        "caretIcon": {
            "text": {
                "color": "#656df9"
            }
        }
    },
    "app-navitem-active": {
        "root": {
            "backgroundColor": "#656df9"
        },
        "navAnchorItem": {
            "text": {
                "color": "#fff"
            },
            "icon": {
                "icon": {
                    "color": "#fff"
                }
            }
        }
    },
    "app-navitem-child": {
        "root": {
            "backgroundColor": "#fff"
        },
        "navAnchorItem": {
            "text": {
                "color": "#656df9"
            },
            "icon": {
                "icon": {
                    "color": "#656df9"
                }
            }
        }
    },
    "app-page-content": {
        "root": {
            "backgroundColor": "#f7f7f8",
            "paddingTop": 0,
            "paddingRight": 0,
            "paddingBottom": 0,
            "paddingLeft": 0
        }
    },
    "flex": {
        "root": {
            "display": "flex",
            "alignItems": "center",
            "justifyContent": "center"
        }
    },
    "p-lg": {
        "root": {
            "paddingTop": 25,
            "paddingRight": 25,
            "paddingBottom": 25,
            "paddingLeft": 25
        }
    },
    "p-md": {
        "root": {
            "paddingTop": 20,
            "paddingRight": 20,
            "paddingBottom": 20,
            "paddingLeft": 20
        }
    },
    "app-tabbar": {
        "menu": {
            "backgroundColor": "#fff",
            "justifyContent": "space-around",
            "alignItems": "baseline"
        },
        "moreMenu": {
            "backgroundColor": "#fff"
        },
        "tabIcon": {
            "icon": {
                "color": "#858ea6",
                "borderBottomColor": "#858ea6",
                "fontSize": 20
            },
            "root": {
                "marginRight": 0,
                "paddingBottom": 35
            }
        },
        "tabLabel": {
            "color": "#9da2a8",
            "fontSize": 11,
            "fontFamily": "Lexend-Medium",
            "fontWeight": "400",
            "marginTop": -30
        },
        "root": {
            "height": 84,
            "paddingTop": 20,
            "paddingLeft": 10,
            "paddingRight": 10,
            "paddingBottom": 0,
            "backgroundColor": "#fff"
        },
        "tabItem": {
            "opacity": 1,
            "minWidth": "auto",
            "maxWidth": 62
        },
        "activeTabIcon": {
            "icon": {
                "color": "#656df9"
            },
            "root": {
                "borderBottomColor": "#656df9"
            }
        },
        "activeTabLabel": {
            "color": "#656df9"
        }
    },
    "app-page": {
        "root": {
            "fontSize": 13
        }
    },
    "app-fileupload": {
        "root": {
            "backgroundColor": "#fff",
            "color": "#30373b",
            "borderColor": "#ccc"
        },
        "button": {
            "text": {
                "color": "#30373b"
            },
            "color": "#30373b",
            "icon": {
                "icon": {
                    "color": "#30373b"
                }
            }
        }
    },
    "app-tabheader": {
        "root": {
            "backgroundColor": "#fff"
        },
        "headerText": {
            "color": "#aaa"
        },
        "activeHeader": {
            "backgroundColor": "#fff"
        },
        "activeHeaderText": {
            "color": "#656df9"
        },
        "activeIndicator": {
            "backgroundColor": "#656df9"
        },
        "arrowIndicator": {
            "backgroundColor": "#fff"
        },
        "arrowIndicatorDot": {
            "backgroundColor": "#fff"
        }
    }
};