export default {
    baseFont: 'Lexend-Regular',
    fonts : [
        {
            name: 'Roboto',
            path: require('./Roboto/Roboto-Regular.ttf')
        },
        {
            name: 'Roboto-Italic',
            path: require('./Roboto/Roboto-Italic.ttf')
        },
        {
            name: 'Roboto-Black',
            path: require('./Roboto/Roboto-Italic.ttf')
        },
        {
            name: 'Roboto-BlackItalic',
            path: require('./Roboto/Roboto-BlackItalic.ttf')
        },
        {
            name: 'Roboto-Bold',
            path: require('./Roboto/Roboto-Bold.ttf')
        },
        {
            name: 'Roboto-Boldtalic',
            path: require('./Roboto/Roboto-BoldItalic.ttf')
        },
        {
            name: 'Roboto-Light',
            path: require('./Roboto/Roboto-Light.ttf')
        },
        {
            name: 'Roboto-LightItalic',
            path: require('./Roboto/Roboto-LightItalic.ttf')
        },
        {
            name: 'Roboto-Medium',
            path: require('./Roboto/Roboto-Medium.ttf')
        },
        {
            name: 'Roboto-MediumItalic',
            path: require('./Roboto/Roboto-MediumItalic.ttf')
        },
        {
            name: 'Roboto-Thin',
            path: require('./Roboto/Roboto-Thin.ttf')
        },
        {
            name: 'Roboto-ThinItalic',
            path: require('./Roboto/Roboto-ThinItalic.ttf')
        },
        {
            name: 'Lexend-Black',
            path: require('./Lexend/Lexend-Black.ttf')
        },
        {
            name: 'Lexend-ExtraBold',
            path: require('./Lexend/Lexend-ExtraBold.ttf')
        },
        {
            name: 'Lexend-Bold',
            path: require('./Lexend/Lexend-Bold.ttf')
        },
        {
            name: 'Lexend-SemiBold',
            path: require('./Lexend/Lexend-SemiBold.ttf')
        },
        {
            name: 'Lexend-Medium',
            path: require('./Lexend/Lexend-Medium.ttf')
        },
        {
            name: 'Lexend-Regular',
            path: require('./Lexend/Lexend-Regular.ttf')
        },
        {
            name: 'Lexend-ExtraLight',
            path: require('./Lexend/Lexend-ExtraLight.ttf')
        },
        {
            name: 'Lexend-Light',
            path: require('./Lexend/Lexend-Light.ttf')
        },
        {
            name: 'Lexend-Thin',
            path: require('./Lexend/Lexend-Thin.ttf')
        },
        {
            name: 'Roboto-Regular',
            path: require('./Roboto/Roboto-Regular.ttf')
        },
        {
            name: 'Roboto-Italic',
            path: require('./Roboto/Roboto-Italic.ttf')
        },
        {
            name: 'Roboto-Black',
            path: require('./Roboto/Roboto-Italic.ttf')
        },
        {
            name: 'Roboto-BlackItalic',
            path: require('./Roboto/Roboto-BlackItalic.ttf')
        },
        {
            name: 'Roboto-Bold',
            path: require('./Roboto/Roboto-Bold.ttf')
        },
        {
            name: 'Roboto-Boldtalic',
            path: require('./Roboto/Roboto-BoldItalic.ttf')
        },
        {
            name: 'Roboto-Light',
            path: require('./Roboto/Roboto-Light.ttf')
        },
        {
            name: 'Roboto-LightItalic',
            path: require('./Roboto/Roboto-LightItalic.ttf')
        },
        {
            name: 'Roboto-Medium',
            path: require('./Roboto/Roboto-Medium.ttf')
        },
        {
            name: 'Roboto-MediumItalic',
            path: require('./Roboto/Roboto-MediumItalic.ttf')
        },
        {
            name: 'Roboto-Thin',
            path: require('./Roboto/Roboto-Thin.ttf')
        },
        {
            name: 'Roboto-ThinItalic',
            path: require('./Roboto/Roboto-ThinItalic.ttf')
        },
    ]
};